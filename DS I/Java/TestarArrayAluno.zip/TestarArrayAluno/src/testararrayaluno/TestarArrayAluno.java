package testararrayaluno;
import java.util.Scanner;


public class TestarArrayAluno {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Aluno[] turma = new Aluno[5];
        
        for(int i = 0; i < turma.length; i++){
        
            turma[i] = new Aluno();
            
            System.out.println("\n\nDigite o nome do aluno: ");
            turma[i].setNome(sc.nextLine());
            
            System.out.println("Digite a nota 1 do aluno: ");
            turma[i].setNota1(sc.nextDouble());
            
            System.out.println("Digite a nota 2 do aluno: ");
            turma[i].setNota2(sc.nextDouble());  
            sc.nextLine();
        }
        
        for(int i = 0; i < turma.length; i++){
            System.out.println("O(a)  aluno(a) " + turma[i].getNome() 
                    + " teve como média das notas: " + turma[i].calcularMedia());
        }
        
    }
    
}
